package com.example.demodec;

public class listItem {

    private String mEvent;

    public listItem(String eventName){
        mEvent=eventName;
    }

    public String getEventName(){
        return mEvent;
    }

}
